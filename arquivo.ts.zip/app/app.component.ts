import { Component } from '@angular/core';
@Component({
selector: '<agenda-aluno>',
templateUrl: './app.component.html',
styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ANGULAR';
  public data: Array<any>;constructor(){
    this.data = [
      { Nome: "Sávio Vinícius de Sousa", RU: ' 2379504 ', CURSOS: 'Engenharia de Software', DN:'21/06/1999' },
          { Name: 'Paulo Guedes', RU: '123456', CURSOS: 'Licenciatura em Artes Visuais', DN:'10.01.1964' },
      { Name: 'Pedro Sampaio', RU: '5146947', CURSOS: 'Matemática',
      DN:'17.08.2002' },
      { Name: 'Dadinho Fernandes ', RU: '7891446', CURSOS: 'Engenharia de Pesca', DN:'20.09.1988' },
      { Name: 'Ítalo Ferreira', RU: '95146456', CURSOS: 'Filosofia',
      DN:'29.07.2004' }
      ];
}
}
